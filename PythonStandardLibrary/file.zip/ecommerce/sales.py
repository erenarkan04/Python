def calc_tax():
    pass


def calc_shipping():
    pass


# __name__ will equal __main__ only if the module is being run directly, not if module is called from a different module

if __name__ == "__main__":
    print("sales started")
    calc_tax()
